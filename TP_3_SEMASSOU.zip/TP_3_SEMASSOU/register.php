<?php
include('db.php');

// Message de confirmation ou d'erreur
$message = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT); // Hashage du mot de passe

    // Vérifier si l'email existe déjà
    $sql_check = "SELECT * FROM users WHERE email='$email'";
    $result = $conn->query($sql_check);
    if ($result->num_rows > 0) {
        $message = '<div class="error">Cet email est déjà utilisé.</div>';
    } else {
        // Insertion des données dans la base de données
        $sql = "INSERT INTO users (username, email, password) VALUES ('$username', '$email', '$password')";
        if ($conn->query($sql) === TRUE) {
            $message = '<div class="success">Votre compte a été créé avec succès. Vous pouvez maintenant vous connecter.</div>';
        } else {
            $message = '<div class="error">Erreur : ' . $conn->error . '</div>';
        }
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulaire d'inscription</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
   
    <form method="POST" action="register.php">
    <h2>Créer votre compte ici : </h2>
    <hr>
    <br>
    <?= $message ?> <!-- Affichage du message de confirmation ou d'erreur -->
        <label>Nom d'utilisateur :</label>
        <input type="text" name="username" required>

        <label>Prénom d'utilisateur :</label>
        <input type="text" name="firstname" required>
        
        <label>Email :</label>
        <input type="email" name="email" required>

        <label>Mot de passe :</label>
        <input type="password" name="password" required>

        <label>Date de naissance :</label>
        <input type="date" name="date_of_birth" required>

        <button type="submit">S'inscrire</button>
    </form>
</body>
</html>
