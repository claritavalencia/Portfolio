<?php
// Connexion à la base de données
$host = 'localhost';
$dbname = 'users';
$username = 'root';
$password = '';
$conn = new mysqli($host, $username, $password, $dbname);

// Vérification de la connexion
if ($conn->connect_error) {
    die("Échec de la connexion : " . $conn->connect_error);
}
?>
