document.addEventListener("DOMContentLoaded", () => {
    const images = document.querySelectorAll('.animate-image');

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('visible'); // Ajoute la classe pour déclencher l'animation
            }
        });
    }, { threshold: 0.1 }); // Déclenche lorsque 10% de l'image est visible

    images.forEach(image => observer.observe(image));

    const interessedButtons = document.querySelectorAll('.interessed-btn');

    interessedButtons.forEach(button => {
        button.addEventListener('click', () => {
            const card = button.closest('.card');
            const messageBtn = card.querySelector('.message-btn');

            // Affiche le bouton "Envoyer un message"
            messageBtn.classList.remove('d-none');
        });
    });
});


