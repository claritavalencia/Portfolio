<?php
// Démarrer la session
session_start();

// Vérifier si l'utilisateur est connecté
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php'); // Rediriger vers la page de connexion si l'utilisateur n'est pas connecté
    exit();
}

echo "Bienvenue, " . $_SESSION['username'] . "!<br>";
?>

<a href="logout.php">Se déconnecter</a>
